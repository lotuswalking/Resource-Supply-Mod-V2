# Resource-Supply-Mod
A Mindustry mod supplying blocks that provide infinite resources, including in campaign maps.


Provides blocks that supply infinite resources, liquids, and power.

<br>

Provides blocks that supply infinite resources, liquids, and power.

<br>

**Feature List:**

0. Item sources are available at the cost of 1 copper each.

1. Liquid sources are available at the cost of 1 copper each.

2. Sources for unlimited energy (power) are available at the cost of 1 copper each.


**End of list.**


Based on https://github.com/xenoforce/opmod


opmod's credits:

    1) Credit goes to xamionex (Opore Mod).

    2) Credit goes to AureusStratus (ExoGenesis mod).

    3) Credit goes to Slotterleet (GoldMod).

    End of credits.
