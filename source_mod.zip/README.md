# The Updated Resource-Supply-Mod
A Mindustry mod supplying blocks that provide infinite resources, including in campaign maps.

It works on both planets!


Provides blocks that supply infinite resources, liquids, and power.

<br>

Provides blocks that supply infinite resources, liquids, and power.

<br>

**Feature List:**

0. Item sources are available at the cost of 1 copper/beryllium each

1. Liquid sources are available at the cost of 1 copper/beryllium each.

2. Sources for unlimited energy (power) are available at the cost of 1 copper/beryllium each.


**End of list.**

This is a fork of 
https://github.com/ocalhoun6/Resource-Supply-Mod


Based on 
https://github.com/ocalhoun6/Resource-Supply-Mod
https://github.com/xenoforce/opmod


opmod's credits:

    1) Credit goes to xamionex (Opore Mod).

    2) Credit goes to AureusStratus (ExoGenesis mod).

    3) Credit goes to Slotterleet (GoldMod).

    End of credits.
